package com.example.sobrevivente_do_apocalipse

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "nightmares.db"
        const val DATABASE_VERSION = 1
        const val TABLE_NAME = "nightmares"
        const val COLUMN_ID = "id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_TAGS = "tags"
        const val COLUMN_DATE = "date"
        const val COLUMN_RATING = "rating"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = "CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_TITLE TEXT, " +
                "$COLUMN_DESCRIPTION TEXT, " +
                "$COLUMN_TAGS TEXT, " +
                "$COLUMN_DATE TEXT, " +
                "$COLUMN_RATING INTEGER)"
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // Função para inserir um novo pesadelo no banco de dados
    fun insertNightmare(title: String, description: String, tags: String, date: String, rating: Int): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TITLE, title)
            put(COLUMN_DESCRIPTION, description)
            put(COLUMN_TAGS, tags)
            put(COLUMN_DATE, date)
            put(COLUMN_RATING, rating)
        }
        // Retorna o ID do novo registro ou -1 em caso de erro
        val newRowId = db.insert(TABLE_NAME, null, values)
        db.close()
        return newRowId
    }

    // Função para recuperar todos os pesadelos
    fun getAllNightmares(): List<Nightmare> {
        val db = readableDatabase
        val cursor: Cursor = db.query(TABLE_NAME, null, null, null, null, null, "$COLUMN_DATE DESC")
        val nightmares = mutableListOf<Nightmare>()

        if (cursor.moveToFirst()) {
            do {
                val nightmare = Nightmare(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                    description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                    tags = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TAGS)),
                    date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)),
                    rating = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_RATING))
                )
                nightmares.add(nightmare)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return nightmares
    }

    data class Nightmare(
        val id: Int,
        val title: String,
        val description: String,
        val tags: String,
        val date: String,
        val rating: Int
    )

    // Função para buscar pesadelos filtrados
    fun getFilteredNightmares(date: String? = null, rating: Int? = null): List<Nightmare> {
        val db = readableDatabase
        val selectionArgs = mutableListOf<String>()
        val selection = mutableListOf<String>()

        date?.let {
            selection.add("$COLUMN_DATE = ?")
            selectionArgs.add(it)
        }

        rating?.let {
            selection.add("$COLUMN_RATING = ?")
            selectionArgs.add(it.toString())
        }

        val cursor = db.query(
            TABLE_NAME,
            null,
            if (selection.isNotEmpty()) selection.joinToString(" AND ") else null,
            if (selectionArgs.isNotEmpty()) selectionArgs.toTypedArray() else null,
            null,
            null,
            "$COLUMN_DATE DESC"
        )

        val nightmares = mutableListOf<Nightmare>()
        if (cursor.moveToFirst()) {
            do {
                val nightmare = Nightmare(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                    description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                    tags = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TAGS)),
                    date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)),
                    rating = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_RATING))
                )
                nightmares.add(nightmare)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return nightmares
    }

}
