package com.example.sobrevivente_do_apocalipse

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ThirdActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var listViewNightmares: ListView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_main)

        listViewNightmares = findViewById(R.id.listViewNightmares)
        val filterButton = findViewById<Button>(R.id.button_filter)

        // Instancia o DatabaseHelper e carrega os pesadelos
        dbHelper = DatabaseHelper(this)
        loadNightmares()

        // Configura o evento de clique nos itens da ListView para exibir detalhes
        listViewNightmares.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val selectedNightmare = dbHelper.getAllNightmares()[position]
            showNightmareDetails(selectedNightmare)
        }

        // Configura o botão de filtro
        filterButton.setOnClickListener {
            showFilterDialog()
        }
    }

    private fun loadNightmares(date: String? = null, rating: Int? = null) {
        val nightmaresList = dbHelper.getFilteredNightmares(date, rating)  // Busca com filtro
        val titlesList = nightmaresList.map { "${it.title} (${it.date})" }

        // Usa o layout personalizado para os itens da lista
        adapter = object : ArrayAdapter<String>(this, R.layout.list_item, titlesList) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(R.id.textViewItem)
                textView.setTextColor(resources.getColor(android.R.color.black))  // Cor preta para o texto
                return view
            }
        }
        listViewNightmares.adapter = adapter
    }

    // Exibe um AlertDialog com os detalhes do pesadelo
    private fun showNightmareDetails(nightmare: DatabaseHelper.Nightmare) {
        val details = """
            Title: ${nightmare.title}
            Date: ${nightmare.date}
            Rating: ${nightmare.rating}
            Tags: ${nightmare.tags}
            Description: ${nightmare.description}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Nightmare Details")
            .setMessage(details)
            .setPositiveButton("Close", null)
            .show()
    }

    // Exibe um diálogo de filtro para selecionar data ou nível de terror
    private fun showFilterDialog() {
        val filterOptions = arrayOf("Date", "Terror Level")
        AlertDialog.Builder(this)
            .setTitle("Filter by")
            .setItems(filterOptions) { _, which ->
                when (which) {
                    0 -> filterByDate()
                    1 -> filterByRating()
                }
            }
            .show()
    }

    private fun filterByDate() {
        // Implementa lógica para filtrar por data
        // Exemplo: Carregar dados de uma data específica e chamar loadNightmares
        val date = "2023-11-14"  // Exemplo: data selecionada no filtro
        loadNightmares(date = date)
    }

    private fun filterByRating() {
        // Implementa lógica para filtrar por nível de terror
        // Exemplo: carregar dados de um rating específico e chamar loadNightmares
        val rating = 5  // Exemplo: nível de terror selecionado no filtro
        loadNightmares(rating = rating)
    }
}
