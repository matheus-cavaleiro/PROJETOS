package com.example.sobrevivente_do_apocalipse

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class SecondActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private var selectedRating: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_main)

        // Inicializa o DatabaseHelper
        dbHelper = DatabaseHelper(this)

        // Elementos da interface
        val editTextDate = findViewById<EditText>(R.id.editTextDate)
        val editTextTitle = findViewById<EditText>(R.id.write_title)
        val editTextDescription = findViewById<EditText>(R.id.write_description)
        val editTextTags = findViewById<EditText>(R.id.write_tags)
        val buttonRegister = findViewById<Button>(R.id.button_register_nightmare)

        // Estrelas de avaliação
        val stars = listOf(
            findViewById<ImageButton>(R.id.star_evaluation1),
            findViewById<ImageButton>(R.id.star_evaluation2),
            findViewById<ImageButton>(R.id.star_evaluation3),
            findViewById<ImageButton>(R.id.star_evaluation4),
            findViewById<ImageButton>(R.id.star_evaluation5)
        )

        // Configura as estrelas para selecionar a avaliação
        stars.forEachIndexed { index, star ->
            star.setOnClickListener {
                selectedRating = index + 1
                updateStarSelection(stars, selectedRating)
            }
        }

        // Abre o DatePickerDialog ao clicar no campo de data
        editTextDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                val date = String.format("%02d/%02d/%04d", selectedDay, selectedMonth + 1, selectedYear)
                editTextDate.setText(date)
            }, year, month, day).show()
        }

        // Botão para salvar as informações no banco de dados
        buttonRegister.setOnClickListener {
            val title = editTextTitle.text.toString()
            val description = editTextDescription.text.toString()
            val tags = editTextTags.text.toString()
            val date = editTextDate.text.toString()

            // Validação básica dos campos
            if (title.isNotEmpty() && description.isNotEmpty() && tags.isNotEmpty() && date.isNotEmpty() && selectedRating > 0) {
                val id = dbHelper.insertNightmare(title, description, tags, date, selectedRating)
                if (id != -1L) {
                    Toast.makeText(this, "Pesadelo registrado com sucesso!", Toast.LENGTH_SHORT).show()

                    // Limpa os campos após o registro
                    editTextTitle.text.clear()
                    editTextDescription.text.clear()
                    editTextTags.text.clear()
                    editTextDate.text.clear()
                    updateStarSelection(stars, 0)  // Restaura a seleção das estrelas

                    // Navega para a terceira tela (ThirdActivity) após o registro bem-sucedido
                    val intent = Intent(this, ThirdActivity::class.java)
                    startActivity(intent)

                } else {
                    Toast.makeText(this, "Erro ao registrar o pesadelo.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Preencha todos os campos e selecione uma avaliação.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Função para atualizar a seleção das estrelas com base na avaliação
    private fun updateStarSelection(stars: List<ImageButton>, rating: Int) {
        stars.forEachIndexed { index, star ->
            if (index < rating) {
                star.setImageResource(R.drawable.button_star_filled)  // Define estrela preenchida
            } else {
                star.setImageResource(R.drawable.button_star)  // Define estrela vazia
            }
        }
    }
}
